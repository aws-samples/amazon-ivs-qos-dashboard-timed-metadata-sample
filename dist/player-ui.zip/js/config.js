export const config = {
  "sendQoSEventUrl": "PLAYER_SUMMARY_ENDPOINT",
  "sendQuizAnswerUrl":"ANSWER_SUMMARY_ENDPOINT",
  "DeliveryStreamName":"DELIVERY_STREAM_NAME",
  "LiveURL": "LIVE_URL"
};
