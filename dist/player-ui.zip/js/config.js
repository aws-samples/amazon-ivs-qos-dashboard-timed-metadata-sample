export const config = {
  "sendQoSEventUrl": "https://uq0y2k5r5i.execute-api.eu-west-1.amazonaws.com/prod2/streams",
  "sendQuizAnswerUrl":"https://uq0y2k5r5i.execute-api.eu-west-1.amazonaws.com/prod2/streams",
  "DeliveryStreamName":"DELIVERY_STREAM_NAME",
  "LiveURL": "https://b1a2a57a7ffd.eu-west-1.playback.live-video.net/api/video/v1/eu-west-1.444603092185.channel.tbHb69cdvlbk.m3u8"
};
