// export const config = {
//   "sendQoSEventUrl": "PLAYER_SUMMARY_ENDPOINT",
//   "sendQuizAnswerUrl":"ANSWER_SUMMARY_ENDPOINT",
//   "DeliveryStreamName":"DELIVERY_STREAM_NAME",
//   "LiveURL": "LIVE_URL"
// };
export const config = {
  "sendQoSEventUrl": "https://59x27snedg.execute-api.eu-west-1.amazonaws.com/prod2/streams",
  "sendQuizAnswerUrl":"https://59x27snedg.execute-api.eu-west-1.amazonaws.com/prod2/streams",
  "DeliveryStreamName":"sfqos4-playerlogs-stream",
  "LiveURL": "https://b1a2a57a7ffd.eu-west-1.playback.live-video.net/api/video/v1/eu-west-1.444603092185.channel.tbHb69cdvlbk.m3u8"
};
